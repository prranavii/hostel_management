from database import view_rooms

room = view_rooms(101)
print(room)